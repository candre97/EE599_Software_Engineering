Question 1
● A tree is a directed graph.
● A tree is a connected graph.
● A tree is an acyclic graph.
● In a tree, there is not a path from each vertex to all other vertices.
● A simple graph is a graph that has no self loops.

Question 2 -- using tabs to separate blocks
i l o v e c o d i n g
i l o v e       c o d i n g
i l     o v e       c o d         i n g
i       l     o         v e       c     o d         i   n g
i       l     o         v        e       c     o        d         i   n         g
i l     o v     e       c o     d i     g n
i l      e o v          c d i o         g n
e i l o v       c d g i n o 
c d e g i i l n o o v

Question 3
Implementation and runtime is in Graph class
Tests in graph_test.cc

Question 4
Implementation and runtime is in Graph class
Tests in graph_test.cc

Question 5
Implementation and runtime is in Maze class
Tests in maze_test.cc

Question 6
Implementation and runtime is in Solution class
Tests in solution_test.cc