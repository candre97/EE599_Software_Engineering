Question 1
implemented in SolutionTest Class
Tested in solution_test.cc

Question 2
implemented in MaxHeap Class
Tested in heap_test.cc

Question 3
implemented in BST Class
Tested in BST_test.cc

Question 4
implemented in BST Class
Tested in BST_test.cc

Question 5
implemented in SolutionTest Class
Tested in solution_test.cc

Question 6
implemented in SolutionTest Class
Tested in solution_test.cc



included MaxHeap.h to get access to heap stuff!