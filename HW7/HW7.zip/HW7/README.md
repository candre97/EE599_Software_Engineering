Question 1
● What is the definition of a path in a graph?
a path is a sequence of edges, which join a sequence of vertices
source: https://en.wikipedia.org/wiki/Path_(graph_theory)
For example, a path from start to finish through a maze might list off all of the vertices that were traversed from start to finish. 
● A simple path is a path that does not repeat vertices (contain any loops)
● A cycle is a path in which there is a repeated vertex
● Topological sort is defined in graphs that are directional acyclic graphs (DAG's)

Question 2
All images in Q2_images folder, labeled by # of hops allowed

Question 3
in solution.cc & solution_test.cc
Still confused why we're encouraged not to use best practice OOP, and create different classes in different files

Question 4
in solution.cc & solution_test.cc

Question 5
in solution.cc & solution_test.cc
